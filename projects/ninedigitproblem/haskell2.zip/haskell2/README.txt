Nine-digit Number Solution in Haskell
Gerg� �rdi (http://gergo.erdi.hu/)

The use of the "choices" function is based on an idea of P�ter
Divi�nszky (http://people.inf.elte.hu/divip/)
