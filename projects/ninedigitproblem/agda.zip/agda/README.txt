9-Digit Problem solutin in Agda
by Gerg� �rdi (http://gergo.erdi.hu/)
