Lista monad FTW!

-- 

   .--= ULLA! =-----------------.   `We are not here to give users what
    \     http://gergo.erdi.hu   \   they want'  -- RMS, at GUADEC 2001
     `---= gergo@erdi.hu =-------'
If it ain't broke, I can fix it.
